import UIKit
// First thing is to set off variables and constant
// The max time given in 3 minutes meaning convert it into seconds
let MaxTime = 180
// Starts the timer at 0 and count till hit 180
for Timer in 0...MaxTime
{
    //Prints each seconds on the time
    print("\(Timer) seconds")
    //Brings up message times up when timer stops at 180
    if Timer == MaxTime{
        print("times up")
    }
}
